#!/bin/sh
java -Xmx512m -XX:MaxDirectMemorySize=512m -jar SimArboreal-Editor.jar
        