#!/bin/sh
java -Xmx768m -XX:MaxDirectMemorySize=768m -jar IsoSurfaceDemo.jar
        