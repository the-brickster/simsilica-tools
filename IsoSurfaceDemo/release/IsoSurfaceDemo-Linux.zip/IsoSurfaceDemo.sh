#!/bin/sh
java  -jar IsoSurfaceDemo.jar
        